from django.forms import inlineformset_factory, modelformset_factory

from .models import Student, Guardian

GuardianFormset = inlineformset_factory(
    Student, Guardian,
    fields=["full_name", "gender", "relation", "mobile_number",
            "email", "occupation"],
    extra=1,
    max_num =3,
    absolute_max=3,
    validate_max=True,
    can_delete=True
)

Students = modelformset_factory(Student, exclude=(), extra=4)

