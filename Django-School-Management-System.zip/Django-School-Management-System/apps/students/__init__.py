default_app_config = "apps.students.apps.StudentsConfig"
